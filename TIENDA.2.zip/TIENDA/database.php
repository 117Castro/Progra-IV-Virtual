<?php
//definimos los datos de la conexion a la BD

//nombre del servidor
define("DB_HOST","localhost");

//nombre de la BD
define("DB_NAME", "bd_tienda");

//contraseña de la BD
define("DB_PWD","");

//nombre de usuario de la BD
define("DB_USER","root");

?>